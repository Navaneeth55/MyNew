package org.websparrow.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.websparrow.dao.ImageDao;
import org.websparrow.dao.UserDao;
import org.websparrow.model.Student;
import org.websparrow.model.User;

@Controller
public class AdminController {

	@Autowired
	UserDao userdao;
	@RequestMapping(value = "/getUser", method = RequestMethod.POST)
	public ModelAndView listStudent(ModelAndView model) throws IOException {

		List<User> listStu = userdao.userList(); 

		List<User> listStu1 = userdao.userListArtist(); 

		model.addObject("listStu1", listStu1);
		model.addObject("listStu", listStu);
		model.setViewName("AdminView");

		return model;
	}


	@RequestMapping(value = "/loginadmin", method = RequestMethod.POST)
	public ModelAndView userLogin(@RequestParam("userId") String userId, @RequestParam("password") String password) {

		ModelAndView mv = new ModelAndView();

		User user = new User();
		user.setUserId(userId);
		user.setPassword(password);
      ;
		String name = userdao.loginAdmin(user);

		if (name != null) {

			mv.addObject("msg", "Welcome " + name + ", You have successfully logged in.");
			mv.setViewName("AdminTrans");

		} else {

			mv.addObject("msg", name+" (or) Invalid user id or password.");
			mv.setViewName("index");
		}

		return mv;

	}

	@RequestMapping(value = "/updateStatus", method = RequestMethod.POST)
	public ModelAndView getUpdate(@RequestParam("userId") String id) {

		ModelAndView mv = new ModelAndView();

		User user = new User();
		user.setUserId(id);
	
		int counter = userdao.updateUser(user);

		if (counter > 0) {
			mv.addObject("msg", "User registration successful.");
		} else {
			mv.addObject("msg", "Error- check the console log.");
		}

		mv.setViewName("index");

		return mv;

	}
	@RequestMapping(value = "/updateStatusrtist", method = RequestMethod.POST)
	public ModelAndView getUpdate1(@RequestParam("userId") String id) {

		ModelAndView mv = new ModelAndView();

		User user = new User();
		user.setUserId(id);
	
		int counter = userdao.updateUserArtist(user);

		if (counter > 0) {
			mv.addObject("msg", "User registration successful.");
		} else {
			mv.addObject("msg", "Error- check the console log.");
		}

		mv.setViewName("index");

		return mv;

	}


}
