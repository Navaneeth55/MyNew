package org.websparrow.model;



	public class User {

		// Generate Getters and Setters...
		private String userId;
		private String password;
		private String admin_enquiry;
		private String mobile;
		public String getMobile() {
			return mobile;
		}
		public void setMobile(String mobile) {
			this.mobile = mobile;
		}
		public String getUserId() {
			return userId;
		}
		public void setUserId(String userId) {
			this.userId = userId;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getAdmin_enquiry() {
			return admin_enquiry;
		}
		public void setAdmin_enquiry(String admin_enquiry) {
			this.admin_enquiry = admin_enquiry;
		}
		
		
		
	}

