package org.websparrow.dao;

import java.util.List;

import org.websparrow.model.User;

public interface UserDao {

	public int updateUser(User user);
	
	public String loginAdmin(User user);
	
	public int registerUser(User user);

	public int updateUserArtist(User user);

	public int registerArtistUser(User user);

	public String loginUser(User user);
	
	public String loginRegisterUser(User user);

	public List<User> userList();
	
	public List<User> userListArtist();
}