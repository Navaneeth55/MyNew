package org.websparrow.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.websparrow.model.Student;
import org.websparrow.model.User;

public class UserDaoImpl implements UserDao {

	private JdbcTemplate jdbcTemplate;

	public UserDaoImpl(DataSource dataSoruce) {
		jdbcTemplate = new JdbcTemplate(dataSoruce);
	}

	@Override
	public int registerUser(User user) {
		
		String sql = "INSERT INTO loginuser VALUES(?,?,?,?)";
     
		try {
			
			int counter = jdbcTemplate.update(sql, new Object[] { user.getUserId(),user.getPassword(),user.getMobile(),"no"});

			return counter;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	 public boolean validateAdmin(User user)
	 {
		 if(user.getAdmin_enquiry().equals("no"))
			 return false;
		 else
			 return true;
	 }
	@Override
	public String loginUser(User user) {
		
		String sql = "SELECT userId FROM loginuser WHERE userId=? AND password=?";
    
		
		try {
			String sql1 = "SELECT admin_enquiry FROM loginuser WHERE userId=?";
			String enq = jdbcTemplate.queryForObject(sql1, new Object[] {
					user.getUserId() }, String.class);
			if(enq.equals("yes")) {
			String userId = jdbcTemplate.queryForObject(sql, new Object[] {
					user.getUserId(), user.getPassword() }, String.class);
			return userId;
			
			}
			else
			{
				return "wait for admin approval";
			}

			
		} catch (Exception e) {
			return null;
		}
		
	
	
}
	@Override
	public String loginAdmin(User user) {
		
		String sql = "SELECT userId FROM admin WHERE userId=? AND password=?";
		
		
		try {

			String userId = jdbcTemplate.queryForObject(sql, new Object[] {
					user.getUserId(), user.getPassword() }, String.class);

			return userId;
			
		} catch (Exception e) {
			return null;
		}
		
		
}
	

	@Override
	public List<User> userList() {

		List<User> list = jdbcTemplate.query("SELECT * FROM loginuser", new RowMapper<User>() {

			@Override
			public User mapRow(ResultSet rs, int rowNum) throws SQLException {
				User stu = new User();
           System.out.println("gyfu");
			 stu.setUserId(rs.getString("userId"));
			 stu.setMobile(rs.getString("mobile"));
			 stu.setPassword(rs.getString("password"));
			 stu.setAdmin_enquiry(rs.getString("admin_enquiry"));
				return stu;
			}
		});

		return list;
	}
	
	@Override
	public int updateUser(User user) {
		
		String sql = "update loginuser set admin_enquiry = ? where userId = ?";
     
		try {
			
			int counter = jdbcTemplate.update(sql, new Object[] {"yes",user.getUserId() });

			return counter;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	@Override
	public int registerArtistUser(User user)
	{
		String sql = "INSERT INTO artist VALUES(?,?,?,?)";
	     
		try {
			
			int counter = jdbcTemplate.update(sql, new Object[] { user.getUserId(),user.getPassword(),user.getMobile(),"no"});

			return counter;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}
	@Override
	public String loginRegisterUser(User user)
	{
String sql = "SELECT userId FROM artist WHERE userId=? AND password=?";
    
		
		try {
			String sql1 = "SELECT admin_enquiry FROM artist WHERE userId=?";
			String enq = jdbcTemplate.queryForObject(sql1, new Object[] {
					user.getUserId() }, String.class);
			if(enq.equals("yes")) {
			String userId = jdbcTemplate.queryForObject(sql, new Object[] {
					user.getUserId(), user.getPassword() }, String.class);
			return userId;
			
			}
			else
			{
				return "wait for admin approval";
			}
	}
		catch (Exception e) {
			return null;
	}
	
}
	@Override
	public int updateUserArtist(User user) {
		String sql = "update artist set admin_enquiry = ? where userId = ?";
	     
		try {
			
			int counter = jdbcTemplate.update(sql, new Object[] {"yes",user.getUserId() });

			return counter;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}	
	}
	
	@Override

	public List<User> userListArtist()
	{
		List<User> list = jdbcTemplate.query("SELECT * FROM artist", new RowMapper<User>() {

			@Override
			public User mapRow(ResultSet rs, int rowNum) throws SQLException {
				User stu = new User();
           System.out.println("gyfu");
			 stu.setUserId(rs.getString("userId"));
			 stu.setMobile(rs.getString("mobile"));
			 stu.setPassword(rs.getString("password"));
			 stu.setAdmin_enquiry(rs.getString("admin_enquiry"));
				return stu;
			}
		});

		return list;
	}
}